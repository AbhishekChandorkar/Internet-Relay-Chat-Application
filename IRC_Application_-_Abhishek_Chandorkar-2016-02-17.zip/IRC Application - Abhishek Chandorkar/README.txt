Instructions to run the application.

1) I have copied the EXE files from the bin/debug folder outside the folders. Firstly, run the Server.exe.

2) Run the client.exe. You will be prompted for Name, Server IP Address and Password. Its details are:
Name: Any name you want
Server IP Address: 127.0.0.1 ( Since application is to be run on Localhost)
Password: Same as the name(case-sensitive)

3) Click on Submit. The Client window pane will appear. Firstly, Create a room. Then create more client instances by running client.exe again. 

4) When done, you can chat between the clients. The server will display an activity log of the activities taking place. For e.g. Client1 has logged in, Client 2 joined the room CS FALL etc.

5) The list box on the right hand side of the client window displays the available and existing chat rooms.

This project has been created using Microsoft Visual C# 2008 Express Edition.